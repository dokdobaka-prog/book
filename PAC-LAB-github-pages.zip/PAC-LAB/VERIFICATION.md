# Verification record

Date: November 5, 2026.

## Source and content review — passed

- Mapped all supplied lectures to weeks 1–9 and the syllabus to weeks 1–10.
- Confirmed the two Week 2 PDF versions have identical extracted text; used one canonical source.
- Recorded physical PDF pages and PPTX slide positions. Week 10 lecture, standalone EndTerm Assignment, previous book source, participant identities, and final public GitHub Pages URL remain unavailable.
- Independently checked source-specific rain-network enumeration, HMM filtering/smoothing/path inference, sensor perceptron update, and original worked examples.
- Checked nine complete chapter schemas, unique district names, story transitions, English teaching text, explained quiz answers, primary-source references, and shipped assets.
- No claim is made that unseen EndTerm requirements have been satisfied.

## Algorithm and interaction checks — passed

`node tests/algorithms.test.mjs`: 164 assertions, including 100 alpha–beta utility orderings. Covers BFS/DFS/UCS/A*, heuristic/goal behavior, pruning equivalence, Bellman updates, Q-learning arithmetic, Bayes boundary cases, HMM normalization, confusion counts, expected loss, perceptron updates, and probability helpers.

`node tests/labs-smoke.test.mjs`: 335 assertions using a DOM double. Mounts all nine experiments and the bonus, exercises controls and reset handlers, verifies reward-dependent MDP choices, checks bonus-chip reachability, and preserves actual perceptron weights when sliders expand beyond their initial bounds. Includes 100 XOR epochs to catch UI clamping.

`node tests/content.test.mjs`: nine complete chapter schemas, source-map matches, English teaching copy, local primary references, missing-source disclosures, and all required static assets.

These are executable code and interaction-handler checks. A DOM double is not a browser rendering engine and does not establish visual correctness or real touch behavior.

## Design and asset review

- Main text width: 720 CSS pixels on desktop. Mobile rules stack the rail, comics, controls, and comparison sections. Narrow-width rules cover 380 pixels and below.
- Reviewed wrapping, native keyboard controls, focus outlines, skip-link behavior, visible labels, polite status announcements, reduced-motion settings, and chapter independence in source.
- Source diagrams are SVG and scale to their containers; tables use contained overflow wrappers. Pixel font is bundled and requires no external network request.
- Exhibition PNG was visually inspected: 1920 × 1080 RGB, 16:9, legible text, consistent palette, no clipping, labeled identity/link fields, no fabricated QR.
- The optional card script creates a QR only from a supplied HTTP(S) URL; it does not verify public access by itself.

## Browser verification limit

The managed preview infrastructure returned `preview relay unavailable`. No replacement preview server or browser installation was used. Local browser rendering, viewport measurements, actual mobile touch interaction, and screen-reader behavior could not be verified through that preview route. See the delivery note for the outcome of the published-site handoff.

## Before final exhibition

Confirm the final public Pages URL opens without an owner login, fill team names and individual contributions, review the missing EndTerm specification, generate the real QR, and scan the exported PNG on a phone. Verify at 360, 390, 768, and 1440 pixels, including long source names, tables, and sliders. These are remaining real-device checks, not results claimed above.


## Compact visual revision — November 6, 2026

- Replaced long default chapter layouts with four freely selectable screens. Detailed source explanations and worked calculations remain collapsed by default.
- Added 60 SVG teaching cards across all nine districts, including the main algorithms and lecture-supported additional methods. Diagrams include accessible descriptions and short captions.
- Rendered all 60 SVGs using sharp and visually inspected contact sheets. Corrected overflowing labels, a misleading architecture chain, and K-means assignment arrows. These are diagram checks, not browser screenshots.
- `node tests/visuals.test.mjs` passes all 60 card schemas and 60 topic navigation checks.
- `node tests/app.test.mjs` now passes 62 integration assertions, including screen selection, keyboard tab switching, hidden-panel state, mobile frame controls, topic/step persistence, and progress reset.
- Re-ran the 164 algorithm and 335 experiment-handler checks; all pass. Content and source-map checks pass.
- Managed browser preview again reported `preview relay unavailable`. Actual page heights, browser layout, and mobile-device rendering remain unverified; the design uses responsive SVG, one visible chapter panel, and keyboard/native controls.
