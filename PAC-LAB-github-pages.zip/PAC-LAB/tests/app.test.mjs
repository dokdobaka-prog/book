/** Routing and progress integration checks with a DOM double, not browser rendering. */
import assert from 'node:assert/strict';
import {firstChapters} from '../dist/chapters-first.js';
import {secondChapters} from '../dist/chapters-second.js';
const chapters=[...firstChapters,...secondChapters].filter(c=>c.id<=9);
const nodes=new Map(),storage=new Map(),listeners={};
class Element {
  constructor(id='',value=''){Object.assign(this,{id,value,handlers:{},attrs:{},disabled:false,hidden:false,dataset:{},_html:'',textContent:''});}
  set innerHTML(html){this._html=html;this.children=new Map();for(const match of html.matchAll(/<(\w+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){const[tag,attrs,id]=[match[1],match[2],match[3]];let value=attrs.match(/\bvalue="([^"]*)"/)?.[1]??'';if(tag==='select')value=html.slice(match.index+match[0].length).match(/<option value="([^"]*)"/)?.[1]??'';const el=new Element(id,value);el.isRange=tag==='input'&&attrs.includes('type="range"');nodes.set(id,el);this.children.set(id,el);}}
  get innerHTML(){return this._html;}
  querySelector(selector){return this.id==='header-progress'&&selector==='span:last-child'?this.lastSpan:this.children?.get(selector.slice(1))??nodes.get(selector.slice(1));}
  querySelectorAll(){return [...(this.children?.values()??[])].filter(el=>el.isRange);}
  addEventListener(type,fn){this.handlers[type]=fn;}
  setAttribute(key,value){this.attrs[key]=value;}
  focus(){} scrollIntoView(){}
}
for(const id of ['main','header-progress','announcement','skip'])nodes.set(id,new Element(id));
nodes.get('header-progress').lastSpan=new Element('count');
globalThis.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)};
globalThis.location={hash:''};
globalThis.window={addEventListener:(type,fn)=>listeners[type]=fn,scrollTo(){},matchMedia:()=>({matches:true})};
globalThis.document={title:'',querySelector:selector=>nodes.get(selector.slice(1)),querySelectorAll:()=>[],getElementById:id=>nodes.get(id)};
globalThis.requestAnimationFrame=fn=>fn();
globalThis.FormData=class {constructor(form){this.form=form;}get(){return this.form.testAnswer??null;}};
await import('../dist/app.js');
const route=hash=>{location.hash=hash;listeners.hashchange();};
let count=0;
for(const chapter of chapters){
  route('#chapter-'+chapter.id);
  assert.ok(nodes.get('main').innerHTML.includes(chapter.title));
  assert.match(nodes.get('main').innerHTML,/id="quiz-form"/);count+=2;
  const form=nodes.get('quiz-form');form.testAnswer=String(chapter.quiz.correct);
  form.handlers.submit({preventDefault(){},currentTarget:form});
  assert.match(nodes.get('quiz-feedback').innerHTML,/That reasoning fits/);
  nodes.get('restore-chip').handlers.click({currentTarget:nodes.get('restore-chip')});count+=2;
}
let saved=JSON.parse(storage.get('paclab-progress-v1'));
assert.deepEqual(saved.chips,[1,2,3,4,5,6,7,8,9]);assert.equal(saved.last,9);assert.equal(Object.keys(saved.answers).length,9);count+=3;
route('#route');assert.match(nodes.get('main').innerHTML,/9 \/ 9 restored/);count++;
route('#bonus');assert.ok(nodes.has('bonus-board'));count++;
route('#sources');assert.match(nodes.get('main').innerHTML,/Week 10 lecture/);count++;
route('#defense');assert.equal((nodes.get('main').innerHTML.match(/Revisit experiment/g)||[]).length,9);count++;
route('#about');nodes.get('reset-progress').handlers.click();assert.equal(nodes.get('reset-confirm').hidden,false);
nodes.get('cancel-reset').handlers.click();assert.equal(nodes.get('reset-confirm').hidden,true);
nodes.get('confirm-reset').handlers.click();saved=JSON.parse(storage.get('paclab-progress-v1'));assert.deepEqual(saved,{chips:[],answers:{},last:1});count+=3;
route('#chapter-99');assert.match(nodes.get('main').innerHTML,/Start Reading/);count++;
route('#chapter-4');const previousHash=location.hash;nodes.get('skip').handlers.click({preventDefault(){}});assert.equal(location.hash,previousHash);count++;
route('#chapter-2');
assert.equal(nodes.get('lesson-panel-0').hidden,false);assert.equal(nodes.get('lesson-panel-1').hidden,true);count+=2;
nodes.get('lesson-next').handlers.click();assert.equal(nodes.get('lesson-panel-0').hidden,true);assert.equal(nodes.get('lesson-panel-1').hidden,false);assert.equal(nodes.get('lesson-tab-1').attrs['aria-selected'],'true');count+=3;
nodes.get('visual-next').onclick();assert.ok(nodes.get('visual-count').textContent.startsWith('2 /'));count++;
route('#chapter-3');route('#chapter-2');assert.equal(nodes.get('lesson-panel-1').hidden,false);assert.ok(nodes.get('visual-count').textContent.startsWith('2 /'));count+=2;
nodes.get('lesson-tab-3').handlers.click();assert.equal(nodes.get('lesson-next').hidden,true);assert.equal(nodes.get('lesson-panel-3').hidden,false);count+=2;
nodes.get('lesson-tab-3').handlers.keydown({key:'ArrowRight',preventDefault(){}});assert.equal(nodes.get('lesson-panel-0').hidden,false);count++;
nodes.get('scene-next').handlers.click();assert.equal(nodes.get('scene-count').textContent,'2 / 3');nodes.get('scene-next').handlers.click();assert.equal(nodes.get('scene-next').disabled,true);count+=2;
route('#about');nodes.get('confirm-reset').handlers.click();assert.deepEqual(JSON.parse(storage.get('paclab-visual-views-v2')),{});count++;
console.log('PASS '+count+' app integration assertions (DOM double; not browser rendering).');
