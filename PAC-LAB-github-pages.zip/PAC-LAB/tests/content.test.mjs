import assert from 'node:assert/strict';
import fs from 'node:fs';
import {firstChapters} from '../dist/chapters-first.js';
import {secondChapters} from '../dist/chapters-second.js';
import {renderSources,renderAbout} from '../dist/notes.js';
const chapters=[...firstChapters,...secondChapters];
assert.deepEqual(chapters.map(c=>c.id),[1,2,3,4,5,6,7,8,9]);
assert.equal(new Set(chapters.map(c=>c.district)).size,9);
let checks=2;
for(const c of chapters){
 assert.equal(c.week,c.id);assert.equal(c.scene.length,3);assert.equal(c.quiz.options.length,3);
 assert.ok(c.quiz.correct>=0&&c.quiz.correct<3);assert.ok(c.quiz.explanation.length>80);
 for(const key of ['title','district','subtitle','problem','explanation','worked','labTitle','labHint','outro','defense'])assert.ok(typeof c[key]==='string'&&c[key].length>8,`${c.id}:${key}`);
 for(const s of c.sources){assert.ok(s.label);assert.ok(s.url==='#sources'||new URL(s.url).protocol==='https:');}
 assert.ok(c.sources.some(s=>s.url==='#sources'));
 assert.ok(!/[А-Яа-яЁё]/.test([c.title,c.problem,c.explanation,c.worked,c.quiz.question,c.outro].join(' ')));
 checks+=20;
}
const sources=renderSources();for(const c of chapters)assert.ok(sources.includes(c.district),`course map district ${c.id}`);
assert.ok(sources.includes('lecture not supplied'));assert.ok(sources.includes('EndTerm Assignment'));
assert.ok(renderAbout(false).includes('unavailable or blocked'));
const html=fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8');
assert.ok(html.includes('lang="en"'));for(const name of ['app.js','style.css','favicon.svg','maze-pixel.ttf','source-audit.json'])assert.ok(fs.statSync(new URL('../dist/'+name,import.meta.url)).isFile());
assert.equal(JSON.parse(fs.readFileSync(new URL('../dist/source-audit.json',import.meta.url))).documents.filter(x=>x.source_status==='lecture supplied').length,9);
console.log(`PASS: nine complete chapter schemas, unique district names, English teaching copy, primary references, source map, and static assets (${checks}+ checks).`);
