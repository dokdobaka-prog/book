import assert from 'node:assert/strict';
import {visualLessons,mountVisualGuide} from '../dist/visual-lessons.js';
assert.deepEqual(Object.keys(visualLessons),['1','2','3','4','5','6','7','8','9']);
let count=0;
for(const [id,cards] of Object.entries(visualLessons)){
 assert.ok(cards.length>=5);
 for(const card of cards){
  assert.ok(card.title.length>8);assert.match(card.diagram,/<svg viewBox="0 0 480 270" role="img" aria-label=/);
  assert.match(card.diagram,/<desc>/);assert.match(card.diagram,/<(?:path|rect|circle|polyline) /);
  assert.ok(card.caption.length>90);assert.ok(!card.diagram.includes('NaN'));assert.ok(!/[А-Яа-я]/.test(card.title+card.caption));
  count++;
 }
}
class Node{
 constructor(){this.value='';this.handlers={};}
 set innerHTML(s){this.html=s;this.children=new Map([...s.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Node()]));}
 querySelector(s){return this.children.get(s.slice(1));}
 addEventListener(k,v){this.handlers[k]=v;}
}
let navigations=0;
for(const [id,cards] of Object.entries(visualLessons)){
 const root=new Node();let selected=-1;mountVisualGuide(root,id,0,n=>selected=n);
 assert.equal(selected,0);assert.equal(root.querySelector('#visual-prev').disabled,true);
 for(let i=1;i<cards.length;i++){root.querySelector('#visual-next').onclick();assert.equal(selected,i);assert.ok(root.querySelector('#visual-board').html.includes(cards[i].title.replaceAll('&','&amp;')));navigations++;}
 assert.equal(root.querySelector('#visual-next').disabled,true);
 root.querySelector('#visual-topic').value='0';root.querySelector('#visual-topic').handlers.change();assert.equal(selected,0);navigations++;
}
console.log(`PASS: ${count} accessible diagram cards across nine chapters; ${navigations} topic navigation checks.`);
