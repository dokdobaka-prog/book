/** Lightweight handler smoke tests. Browser layout/accessibility still needs visual QA. */
import assert from 'node:assert/strict';
import { mountLab } from '../dist/labs.js';
import { perceptronEpoch } from '../dist/algorithms.js';
class Element {
 constructor(value=''){this.value=value;this.innerHTML='';this.textContent='';this.handlers={};this.disabled=false;}
 get value(){return this._value;}
 set value(v){this._value=this.range?String(Math.min(Number(this.max),Math.max(Number(this.min),Number(v)))):String(v);}
 addEventListener(type,fn){this.handlers[type]=fn;}
 fire(type){this.handlers[type]?.({key:'ArrowRight',preventDefault(){}});}
 click(){this.onclick?.();}
}
class Container {
 constructor(){this.elements=new Map();}
 set innerHTML(html){this.html=html;for(const match of html.matchAll(/<(\w+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){const[tag,attrs,id]=[match[1],match[2],match[3]];let value=attrs.match(/\bvalue="([^"]*)"/)?.[1]??'';if(tag==='select')value=html.slice(match.index+match[0].length).match(/<option value="([^"]*)"/)?.[1]??'';const el=new Element(value);el.range=tag==='input'&&attrs.includes('type="range"');if(el.range){el.min=attrs.match(/\bmin="([^"]*)"/)?.[1]??'0';el.max=attrs.match(/\bmax="([^"]*)"/)?.[1]??'100';el.value=value;}this.elements.set(id,el);}}
 querySelector(selector){return this.elements.get(selector.slice(1))??null;}
 querySelectorAll(selector){return [...this.elements.values()].filter(x=>x.range);}
}
let checks=0;
for(const id of [1,2,3,4,5,6,7,8,9,'bonus']){
 const c=new Container();assert.equal(typeof mountLab(c,id),'function');checks++;
 const q=id=>c.querySelector('#'+id);
 if(id===1){q('goal').value='safety';q('goal').fire('change');assert.match(q('lab-result').innerHTML,/inspected/);checks++;}
 if(id===2){for(const kind of ['bfs','dfs','ucs','astar']){q('search-kind').value=kind;q('search-kind').fire('change');q('search-all').click();assert.match(q('lab-result').innerHTML,/Solution:/);checks++;}}
 if(id===3){q('climb').click();q('climb').click();q('climb').click();assert.match(q('local-status').innerHTML,/local maximum/);q('restart').click();q('climb').click();assert.match(q('local-status').innerHTML,/strength 9/);checks+=2;}
 if(id===4){for(const mode of ['minimax','alphabeta','expectimax']){q('tree-mode').value=mode;q('tree-mode').fire('change');assert.match(q('lab-result').innerHTML,/Pac-Man/);checks++;}q('tree-mode').value='minimax';q('tree-mode').fire('change');q('tree-step').click();assert.match(q('tree-trace').textContent,/1 \/ 3/);q('tree-step').click();assert.match(q('tree-trace').textContent,/2 \/ 3/);q('tree-step').click();assert.match(q('lab-result').innerHTML,/4.00/);checks+=3;}
 if(id===5){
  q('iterate').click();q('q-update').click();assert.match(q('lab-result').innerHTML,/1.800/);checks++;
  q('wait-reward').value='0';q('wait-reward').fire('input');
  assert.match(q('mdp-output').innerHTML,/V\(A\)<\/span><strong>0.000/);assert.match(q('lab-result').innerHTML,/Q\(A, move\)<\/span><strong>0.000/);checks+=2;
  q('iterate').click();assert.match(q('mdp-output').innerHTML,/Greedy action at B<\/span><strong>exit/);checks++;
  q('wait-reward').value='1';q('wait-reward').fire('input');q('iterate').click();assert.match(q('mdp-output').innerHTML,/Greedy action at B<\/span><strong>wait/);checks++;
 }
 if(id===6){q('prior').value='0';q('false-positive').value='0';q('prior').fire('input');assert.match(q('lab-result').innerHTML,/Undefined/);checks++;}
 if(id===7){q('red-signal').click();assert.match(q('lab-result').innerHTML,/75.0%/);q('red-signal').click();assert.match(q('lab-result').innerHTML,/84.8%/);checks+=2;}
 if(id===8){assert.match(q('lab-result').innerHTML,/75.0%/);checks++;}
 if(id===9){
  q('target-gate').value='OR';q('target-gate').fire('change');q('weight-one').value=3;q('weight-two').value=-3;q('bias').value=-3;
  q('train-gate').click();assert.equal(Number(q('weight-one').value),3.2);assert.ok(Number(q('weight-one').max)>=3.2);checks+=2;
  q('reset-gate').click();assert.equal(q('weight-one').max,'3');assert.equal(q('weight-one').min,'-3');checks+=2;
  q('target-gate').value='XOR';q('target-gate').fire('change');let expected={w1:1,w2:1,b:-1.5};
  for(let epoch=0;epoch<100;epoch++){expected=perceptronEpoch(expected,'XOR',.2).weights;q('train-gate').click();for(const[key,id]of [['w1','weight-one'],['w2','weight-two'],['b','bias']]){assert.ok(Math.abs(Number(q(id).value)-expected[key])<1e-8);checks++;}}
  assert.match(q('lab-result').innerHTML,/online updates/);checks++;
 }
 if(id==='bonus'){q('move-right').click();assert.match(q('lab-result').innerHTML,/Moves/);checks++;}
}
console.log('PASS: '+checks+' lab mounting and handler checks (not browser rendering).');
