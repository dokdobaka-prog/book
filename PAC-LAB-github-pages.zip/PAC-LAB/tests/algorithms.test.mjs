import assert from 'node:assert/strict';
import {GRAPH,searchGraph,bayes,hmmUpdate,gameTree,valueIteration,qUpdate,confusion,expectedLoss,perceptronPredict,perceptronEpoch,tokenProbabilities,seededSample} from '../dist/algorithms.js';
let checks=0;
const near=(actual,expected,tolerance=1e-10)=>{assert.ok(Math.abs(actual-expected)<tolerance,`${actual} != ${expected}`);checks++;};
for(const method of ['BFS','DFS','UCS','A*']){const r=searchGraph(method);assert.equal(r.path[0],'S');assert.equal(r.path.at(-1),'G');assert.equal(new Set(r.expanded).size,r.expanded.length);assert.equal(r.steps.length,r.expanded.length);checks+=4;}
assert.equal(searchGraph('BFS').cost,10);assert.equal(searchGraph('DFS').cost,4);assert.equal(searchGraph('UCS').cost,4);assert.equal(searchGraph('A*').cost,4);checks+=4;
for(const [a,b,cost] of GRAPH.edges){assert.ok(GRAPH.nodes[a].h<=cost+GRAPH.nodes[b].h);checks++;}
near(bayes(.1,.8,.2),4/13);assert.equal(bayes(0,0,0),null);checks++;near(bayes(1,1,.2),1);near(bayes(0,.8,.2),0);assert.throws(()=>bayes(-.1));checks++;
const first=hmmUpdate(.5,true);near(first.predicted,.5);near(first.posterior,.75);const second=hmmUpdate(first.posterior,true);near(second.predicted,.65);near(second.posterior,39/46);near(hmmUpdate(.5,false).posterior,.25);assert.equal(hmmUpdate(1,false,1,1).posterior,null);checks++;
const full=gameTree(),pruned=gameTree(undefined,'alpha-beta');assert.equal(full.value,4);assert.equal(pruned.value,full.value);assert.equal(pruned.branch,full.branch);assert.deepEqual(pruned.pruned,[3]);assert.equal(pruned.visited.length,5);assert.equal(gameTree(undefined,'expectimax').value,5.5);checks+=6;
// Alpha-beta must preserve root value across utility orderings and signs.
for(let i=0;i<100;i++){const leaf=Array.from({length:6},(_,j)=>((i*31+j*17)%47)-20);assert.equal(gameTree(leaf,'alpha-beta').value,gameTree(leaf).value);checks++;}
let values=[0,0];let result;for(let i=0;i<250;i++){result=valueIteration(values);values=result.values;}near(values[1],10,1e-8);near(values[0],9,1e-8);assert.deepEqual(result.policy,['transfer','wait']);checks++;assert.throws(()=>valueIteration([0,0],1));checks++;near(qUpdate(0,1,2),1.4);
assert.deepEqual(confusion(.5),{tp:3,fp:1,tn:3,fn:1,accuracy:.75});assert.deepEqual(confusion(0),{tp:4,fp:4,tn:0,fn:0,accuracy:.5});assert.deepEqual(confusion(1),{tp:0,fp:0,tn:4,fn:4,accuracy:.5});checks+=3;
assert.deepEqual(expectedLoss(.3),{sendLoss:30,inspectLoss:12,threshold:.12,choice:'inspect'});assert.equal(expectedLoss(.1).choice,'send');checks+=2;
let w={w1:0,w2:0,b:0};for(let i=0;i<25;i++)w=perceptronEpoch(w,'AND').weights;for(const [a,b] of [[0,0],[0,1],[1,0],[1,1]]){assert.equal(perceptronPredict(w,a,b),a&b);checks++;}for(let i=0;i<30;i++){const out=perceptronEpoch(w,'XOR');w=out.weights;}assert.ok([[0,0],[0,1],[1,0],[1,1]].some(([a,b])=>perceptronPredict(w,a,b)!==(a^b)));checks++;
near(tokenProbabilities(1).reduce((a,b)=>a+b),1);assert.deepEqual(tokenProbabilities(0),[1,0,0]);checks++;assert.ok(tokenProbabilities(.2)[0]>tokenProbabilities(2)[0]);checks++;assert.equal(seededSample([1,0,0],42).index,0);assert.deepEqual(seededSample([.2,.3,.5],42),seededSample([.2,.3,.5],42));checks+=2;
console.log(`PASS: ${checks} algorithm assertions, including 100 alpha-beta utility orderings.`);
