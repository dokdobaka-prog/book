#!/usr/bin/env python3
"""Render the PAC-LAB exhibition card. No URL means no QR code.

Usage: python3 tools/make_card.py --output ../deliverables/PAC-LAB-exhibition-card.png
Add --team '07' --names 'First Last · First Last' for the final exhibition copy.
Add --url https://OWNER.github.io/REPOSITORY/ only after confirming that URL
is the public, accessible book. The script never invents a destination.
"""
from __future__ import annotations
import argparse
from pathlib import Path
from urllib.parse import urlparse
from PIL import Image, ImageDraw, ImageFont

BG = '#0B1020'
WHITE = '#E8ECF5'
MUTED = '#9DA9C3'
YELLOW = '#FFD84D'
BLUE = '#4263EB'
LINE = '#263557'


def font(size, bold=False, mono=False):
    face = 'DejaVuSansMono' if mono else 'DejaVuSans'
    if bold:
        face += '-Bold'
    return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/' + face + '.ttf', size)


def wrap(draw, text, face, width):
    lines, line = [], ''
    for word in text.split():
        trial = (line + ' ' + word).strip()
        if draw.textlength(trial, font=face) > width and line:
            lines.append(line)
            line = word
        else:
            line = trial
    if line:
        lines.append(line)
    return lines


def pixel_sprite(draw, grid, x, y, scale, color):
    for row, cells in enumerate(grid):
        for col, cell in enumerate(cells):
            if cell == '1':
                draw.rectangle((x+col*scale, y+row*scale,
                                x+(col+1)*scale-1, y+(row+1)*scale-1), fill=color)
            elif cell == '2':
                draw.rectangle((x+col*scale, y+row*scale,
                                x+(col+1)*scale-1, y+(row+1)*scale-1), fill=WHITE)
            elif cell == '3':
                draw.rectangle((x+col*scale, y+row*scale,
                                x+(col+1)*scale-1, y+(row+1)*scale-1), fill=BG)


PAC = [
    '00011110000', '00111111000', '01111111100', '11111110000',
    '11111000000', '11111110000', '01111111100', '00111111000', '00011110000'
]
GHOST = [
    '0001111000', '0011111100', '0111111110', '1122112211',
    '1123112311', '1111111111', '1111111111', '1111111111', '1101101101'
]


def render(output, team, names, url):
    image = Image.new('RGB', (1920,1080), BG)
    d = ImageDraw.Draw(image)
    # Open editorial grid. The right-hand illustration remains subordinate.
    d.text((96,70), 'AI FUNDAMENTALS  /  INTERACTIVE BOOK', font=font(23,mono=True), fill=MUTED)
    d.line((96,119,1824,119), fill=LINE, width=2)
    d.text((88,176), 'PAC-LAB', font=font(137,bold=True), fill=YELLOW)
    d.text((97,345), 'The Lost Memory Chips', font=font(45), fill=WHITE)
    annotation = ('Maze City has lost its memory. Join Pac-Man and Byte to recover nine chips, '
                  'test ideas in interactive experiments, and discover how intelligent systems '
                  'search, reason, learn, and make responsible decisions.')
    y=451
    for line in wrap(d,annotation,font(31),940):
        d.text((99,y),line,font=font(31),fill=WHITE)
        y+=47
    d.text((99,685),'GROUP',font=font(19,mono=True),fill=MUTED)
    d.text((99,721),team,font=font(30,bold=True),fill=WHITE)
    d.text((99,797),'CREATORS',font=font(19,mono=True),fill=MUTED)
    y=831
    for line in wrap(d,names,font(28),990)[:2]:
        d.text((99,y),line,font=font(28),fill=WHITE)
        y+=39

    # Thin-lined, flat city maze and deliberately pixel-built characters.
    ox,oy=1185,190
    d.text((ox,oy-36),'MAZE CITY  /  09 DISTRICTS',font=font(18,mono=True),fill=MUTED)
    paths=[
      [(0,0),(620,0),(620,438),(0,438),(0,0)],
      [(44,84),(44,42),(250,42),(250,123),(370,123),(370,42),(576,42),(576,140)],
      [(0,172),(130,172),(130,84),(205,84)],
      [(44,221),(205,221),(205,172),(290,172),(290,261),(370,261)],
      [(420,84),(420,172),(530,172),(530,261),(620,261)],
      [(44,312),(130,312),(130,393),(290,393),(290,312),(420,312),(420,221)],
      [(0,353),(82,353)],
      [(370,393),(576,393),(576,312),(480,312)],
      [(480,438),(480,353)],
      [(250,0),(250,42)],
    ]
    for path in paths:
        d.line([(ox+x,oy+y) for x,y in path],fill=BLUE,width=3,joint='curve')
    # Route dots become restored memory markers. Only the chip has a halo.
    for x,y in [(86,83),(86,125),(86,220),(248,219),(329,219),(461,219),(576,218),(173,352),(218,352)]:
        d.rectangle((ox+x-3,oy+y-3,ox+x+3,oy+y+3),fill='#B0B9CF')
    pixel_sprite(d,PAC,ox+158,oy+112,7,YELLOW)
    pixel_sprite(d,GHOST,ox+327,oy+35,6,'#78AAFF')
    pixel_sprite(d,GHOST,ox+466,oy+342,5,'#E87291')
    # Memory chip, one restrained emphasis.
    cx,cy=ox+449,oy+78
    d.rectangle((cx-9,cy-9,cx+40,cy+40),outline='#393622',width=1)
    d.rectangle((cx,cy,cx+31,cy+31),outline=YELLOW,width=3)
    d.rectangle((cx+9,cy+9,cx+22,cy+22),fill=YELLOW)
    for a in (6,16,26):
        d.line((cx+a,cy-5,cx+a,cy),fill=YELLOW,width=2)
        d.line((cx+a,cy+31,cx+a,cy+36),fill=YELLOW,width=2)
        d.line((cx-5,cy+a,cx,cy+a),fill=YELLOW,width=2)
        d.line((cx+31,cy+a,cx+36,cy+a),fill=YELLOW,width=2)
    d.text((ox+2,oy+470),'SEARCH  ·  REASON  ·  LEARN',font=font(20,mono=True),fill=MUTED)

    # A public destination is a necessary input, never a fabricated QR code.
    qx,qy=1185,756
    if url:
        from reportlab.graphics.barcode import qrencoder
        qr=qrencoder.QRCode(4,qrencoder.QRErrorCorrectLevel.M)
        qr.addData(url)
        qr.make()
        count=len(qr.modules)
        qi=Image.new('RGB',((count+8)*4,(count+8)*4),'white')
        qdraw=ImageDraw.Draw(qi)
        for row, cells in enumerate(qr.modules):
            for col, value in enumerate(cells):
                if value:
                    x=(col+4)*4;y=(row+4)*4
                    qdraw.rectangle((x,y,x+3,y+3),fill=BG)
        image.paste(qi,(qx,qy))
        label='SCAN TO READ'
        sub='Public book link'
    else:
        d.rectangle((qx,qy,qx+166,qy+166),outline=LINE,width=2)
        d.text((qx+34,qy+62),'QR CODE',font=font(20,mono=True),fill=MUTED)
        label='PUBLIC LINK PENDING'
        sub='Add after public URL\nis confirmed.'
    d.text((qx+200,qy+13),label,font=font(20,bold=True),fill=WHITE)
    d.multiline_text((qx+200,qy+55),sub,font=font(24),fill=MUTED,spacing=10)
    d.line((96,970,1824,970),fill=LINE,width=2)
    public_text='PUBLIC BOOK URL: ' + (url or '[TO BE ADDED]')
    for line in wrap(d,public_text,font(18,mono=True),1725):
        d.text((99,989),line,font=font(18,mono=True),fill=MUTED)
        break
    d.text((99,1025),'A nine-district journey through the foundations of AI.',font=font(19),fill=MUTED)
    output=Path(output)
    output.parent.mkdir(parents=True,exist_ok=True)
    image.save(output,optimize=True)
    return output


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default='../deliverables/PAC-LAB-exhibition-card.png')
    parser.add_argument('--team',default='[TEAM NUMBER]')
    parser.add_argument('--names',default='[PARTICIPANT NAMES]')
    parser.add_argument('--url',default='',help='Confirmed public book URL; leave empty to reserve the QR field.')
    args=parser.parse_args()
    if args.url:
        parsed=urlparse(args.url)
        if parsed.scheme not in ('https','http') or not parsed.netloc:
            parser.error('--url must be a complete http(s) URL.')
    output=render(args.output,args.team,args.names,args.url)
    with Image.open(output) as check:
        assert check.size==(1920,1080) and check.mode=='RGB'
    print(f'{output.resolve()} — 1920 × 1080 RGB; QR: {"generated from supplied URL" if args.url else "reserved, no destination supplied"}')


if __name__=='__main__':
    main()
