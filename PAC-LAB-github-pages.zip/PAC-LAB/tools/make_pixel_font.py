#!/usr/bin/env python3
"""Build Maze Pixel, an original, dependency-free-at-runtime 5×7 label font.

The drawing alphabet is authored here as bitmap cells. Every filled cell is a
100-unit square outline in the TTF, with a six-cell monospace advance. Use the
font only for short labels, preferably at 10px (one cell = one CSS pixel) or
20px. Lowercase codepoints intentionally repeat the uppercase designs.

Build dependency: fonttools. Output: ../dist/maze-pixel.ttf.
"""
from pathlib import Path
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont


PATTERNS = {
    'A':'01110/10001/10001/11111/10001/10001/10001',
    'B':'11110/10001/10001/11110/10001/10001/11110',
    'C':'01111/10000/10000/10000/10000/10000/01111',
    'D':'11110/10001/10001/10001/10001/10001/11110',
    'E':'11111/10000/10000/11110/10000/10000/11111',
    'F':'11111/10000/10000/11110/10000/10000/10000',
    'G':'01111/10000/10000/10111/10001/10001/01111',
    'H':'10001/10001/10001/11111/10001/10001/10001',
    'I':'11111/00100/00100/00100/00100/00100/11111',
    'J':'00111/00010/00010/00010/10010/10010/01100',
    'K':'10001/10010/10100/11000/10100/10010/10001',
    'L':'10000/10000/10000/10000/10000/10000/11111',
    'M':'10001/11011/10101/10101/10001/10001/10001',
    'N':'10001/11001/10101/10011/10001/10001/10001',
    'O':'01110/10001/10001/10001/10001/10001/01110',
    'P':'11110/10001/10001/11110/10000/10000/10000',
    'Q':'01110/10001/10001/10001/10101/10010/01101',
    'R':'11110/10001/10001/11110/10100/10010/10001',
    'S':'01111/10000/10000/01110/00001/00001/11110',
    'T':'11111/00100/00100/00100/00100/00100/00100',
    'U':'10001/10001/10001/10001/10001/10001/01110',
    'V':'10001/10001/10001/10001/10001/01010/00100',
    'W':'10001/10001/10001/10101/10101/10101/01010',
    'X':'10001/10001/01010/00100/01010/10001/10001',
    'Y':'10001/10001/01010/00100/00100/00100/00100',
    'Z':'11111/00001/00010/00100/01000/10000/11111',
    '0':'01110/10001/10011/10101/11001/10001/01110',
    '1':'00100/01100/00100/00100/00100/00100/01110',
    '2':'01110/10001/00001/00010/00100/01000/11111',
    '3':'11110/00001/00001/01110/00001/00001/11110',
    '4':'00010/00110/01010/10010/11111/00010/00010',
    '5':'11111/10000/10000/11110/00001/00001/11110',
    '6':'01110/10000/10000/11110/10001/10001/01110',
    '7':'11111/00001/00010/00100/01000/01000/01000',
    '8':'01110/10001/10001/01110/10001/10001/01110',
    '9':'01110/10001/10001/01111/00001/00001/01110',
    ' ':'00000/00000/00000/00000/00000/00000/00000',
    '!':'00100/00100/00100/00100/00100/00000/00100',
    '"':'01010/01010/01010/00000/00000/00000/00000',
    '#':'01010/01010/11111/01010/11111/01010/01010',
    '$':'00100/01111/10100/01110/00101/11110/00100',
    '%':'11001/11010/00010/00100/01000/01011/10011',
    '&':'01100/10010/10100/01000/10101/10010/01101',
    "'":'00100/00100/01000/00000/00000/00000/00000',
    '(':'00010/00100/01000/01000/01000/00100/00010',
    ')':'01000/00100/00010/00010/00010/00100/01000',
    '*':'00000/10101/01110/11111/01110/10101/00000',
    '+':'00000/00100/00100/11111/00100/00100/00000',
    ',':'00000/00000/00000/00000/00100/00100/01000',
    '-':'00000/00000/00000/11111/00000/00000/00000',
    '.':'00000/00000/00000/00000/00000/00100/00100',
    '/':'00001/00010/00010/00100/01000/01000/10000',
    ':':'00000/00100/00100/00000/00100/00100/00000',
    ';':'00000/00100/00100/00000/00100/00100/01000',
    '<':'00001/00010/00100/01000/00100/00010/00001',
    '=':'00000/00000/11111/00000/11111/00000/00000',
    '>':'10000/01000/00100/00010/00100/01000/10000',
    '?':'01110/10001/00001/00010/00100/00000/00100',
    '@':'01110/10001/10111/10101/10111/10000/01111',
    '[':'01110/01000/01000/01000/01000/01000/01110',
    '\\':'10000/01000/01000/00100/00010/00010/00001',
    ']':'01110/00010/00010/00010/00010/00010/01110',
    '^':'00100/01010/10001/00000/00000/00000/00000',
    '_':'00000/00000/00000/00000/00000/00000/11111',
    '`':'01000/00100/00000/00000/00000/00000/00000',
    '{':'00011/00100/00100/11000/00100/00100/00011',
    '|':'00100/00100/00100/00100/00100/00100/00100',
    '}':'11000/00100/00100/00011/00100/00100/11000',
    '~':'00000/00000/01001/10110/00000/00000/00000',
    '·':'00000/00000/00000/00100/00000/00000/00000',
    '→':'00000/00100/00010/11111/00010/00100/00000',
    '←':'00000/00100/01000/11111/01000/00100/00000',
    '✓':'00000/00001/00010/10100/01000/00000/00000',
}


def glyph(bitmap):
    pen=TTGlyphPen(None)
    rows=bitmap.split('/')
    assert len(rows)==7 and all(len(row)==5 for row in rows)
    for row,cells in enumerate(rows):
        for col,cell in enumerate(cells):
            if cell=='1':
                x,y=col*100,(6-row)*100
                pen.moveTo((x,y))
                pen.lineTo((x,y+100))
                pen.lineTo((x+100,y+100))
                pen.lineTo((x+100,y))
                pen.closePath()
    return pen.glyph()


def main():
    out=Path(__file__).resolve().parents[1]/'dist'/'maze-pixel.ttf'
    maps={ord(char):'uni'+format(ord(char),'04X') for char in PATTERNS}
    for char in 'abcdefghijklmnopqrstuvwxyz':
        maps[ord(char)]=maps[ord(char.upper())]
    notdef='11111/10001/10101/10101/10101/10001/11111'
    glyphs={'.notdef':glyph(notdef)}
    for char,bitmap in PATTERNS.items():
        glyphs[maps[ord(char)]]=glyph(bitmap)
    names=['.notdef']+[name for name in maps.values() if name!='.notdef']
    names=list(dict.fromkeys(names))
    fb=FontBuilder(1000,isTTF=True)
    fb.setupGlyphOrder(names)
    fb.setupCharacterMap(maps)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics({name:(600,0) for name in names})
    fb.setupHorizontalHeader(ascent=800,descent=-200)
    fb.setupNameTable({
        'familyName':'Maze Pixel',
        'styleName':'Regular',
        'uniqueFontIdentifier':'PAC-LAB Maze Pixel Regular 1.0',
        'fullName':'Maze Pixel Regular',
        'psName':'MazePixel-Regular',
        'version':'Version 1.0',
        'copyright':'Original 5x7 bitmap alphabet created for PAC-LAB, 2026. CC0.',
        'licenseDescription':'Dedicated to the public domain under CC0 1.0.',
        'licenseInfoURL':'https://creativecommons.org/publicdomain/zero/1.0/',
    })
    fb.setupOS2(sTypoAscender=800,sTypoDescender=-200,sTypoLineGap=0,
                usWinAscent=800,usWinDescent=200,sCapHeight=700,sxHeight=700)
    fb.setupPost(isFixedPitch=1)
    fb.setupMaxp()
    out.parent.mkdir(parents=True,exist_ok=True)
    fb.save(out)
    check=TTFont(out)
    assert all(code in check.getBestCmap() for code in range(32,127))
    assert check['head'].unitsPerEm==1000
    print(f'{out}: {len(check.getBestCmap())} mapped characters, {out.stat().st_size} bytes')


if __name__=='__main__':
    main()
