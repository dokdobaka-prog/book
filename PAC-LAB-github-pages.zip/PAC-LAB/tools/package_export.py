"""Export the book and reproducible source without hosting identity or Git data."""
import argparse
from pathlib import Path
import zipfile

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    parser.add_argument('--card')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    selected=[]
    for directory in ['dist','tools','tests']:
        selected.extend(p for p in (root/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    for name in ['README.md','VERIFICATION.md','package.json','source-audit.json','SUBMISSION-NOTES.md']:
        selected.append(root/name)
    output=Path(args.output)
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(selected):
            archive.write(path,Path('PAC-LAB')/path.relative_to(root))
        if args.card:
            card=Path(args.card)
            archive.write(card,Path('PAC-LAB')/'exhibition'/card.name)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert 'PAC-LAB/dist/index.html' in archive.namelist()
        assert not any('/.git/' in name or '/.openai/' in name for name in archive.namelist())
    print(f'Exported {output.name}: {len(selected)} source files plus exhibition card' if args.card else f'Exported {output.name}: {len(selected)} source files')

if __name__=='__main__':
    main()
