# PAC-LAB: The Lost Memory Chips

A finished, buildless English interactive book about AI Fundamentals. Nine connected districts follow the supplied lectures for weeks 1–9; the course map explicitly marks the missing Week 10 lecture and standalone EndTerm Assignment.

## Open the book

Use the deployed draft link supplied with delivery, or host the contents of `dist/` on any static HTTP(S) host. Opening `index.html` directly as a `file://` URL can block JavaScript modules in browsers; use an HTTP server for local development. The published book requires no build, API key, account, or backend.

## Publish on GitHub Pages

1. Create a GitHub repository, or select the intended repository.
2. Upload **the contents inside `dist/`**, including `.nojekyll`, to the repository root. `index.html` must be at that root.
3. In **Settings → Pages → Build and deployment**, choose **Deploy from a branch**, then the branch you uploaded and **/ (root)**. Save.
4. Wait for GitHub Pages to report the published URL. Open that exact URL and check a chapter, an experiment, and a page reload.
5. Add the verified public URL and participant details to `dist/notes.js`. Regenerate the exhibition card with that public URL, then upload the updated site files.

All asset and module URLs are relative; hash routing works on repository subpaths and requires no server rewrite. No third-party font or CDN request is necessary. If publishing the whole development project rather than uploading `dist/` contents, configure a GitHub Actions Pages workflow to upload `dist/` as its artifact.

GitHub documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Compact visual reading

Each chapter now uses four freely selectable screens: **Story → Visual guide → Experiment → Reflect**. Sixty SVG teaching cards explain concepts one at a time with exact diagrams and short captions. The topic selector jumps directly to an idea; definitions, full calculations, and limitations remain in closed-by-default notes. Mobile comic scenes use frame buttons. Current screen and visual topic are saved locally, independently from restored chips. Nothing is locked by a score.

## Included experience

- Nine chapters with three-panel scenes, a concrete problem, definitions, algorithms, exact examples, a live experiment, an explained quiz, and a continuing story.
- BFS / DFS / UCS / A*, local search and channel CSP, minimax / alpha–beta / expectimax, MDP planning and a sampled Q update, Bayes, HMM filtering, cost-based decisions and validation metrics, perceptron learning and multilayer XOR.
- Additional lecture-supported methods in compact notes.
- Separate keyboard/touch bonus maze.
- Sources, week mapping and gaps, credits fields, AI-use declaration, oral-defense questions.
- Browser-local restored chips, quiz selections, and last chapter; every chapter is always readable.

## Files and editing

`dist/chapters-first.js` and `dist/chapters-second.js` hold the English book. `dist/algorithms.js` holds pure algorithm implementations; `dist/labs.js` supplies the controls and diagrams. `dist/app.js` handles compact chapter screens, quizzes, and local progress. `dist/visual-lessons.js` contains the sixty accessible teaching diagrams and topic navigation. `dist/notes.js` holds sources, contributors, and disclosure. `dist/style.css` holds shared responsive design tokens. `source-audit.json` contains the full attachment map.

The supplied lecture files are cited but not republished inside the website. The original story, code, city art, and pixel font are new. Pac-Man belongs to Bandai Namco; this is an unofficial educational work. See the source notes for supplementary references.

## Reproduce checks

Node.js 20 or newer:

```sh
node tests/algorithms.test.mjs
node tests/labs-smoke.test.mjs
node tests/content.test.mjs
node tests/visuals.test.mjs
node tests/app.test.mjs
```

These checks need no npm installation. See `VERIFICATION.md` for the checks performed and limits. The optional full-DOM integration check uses the environment-provided jsdom installation and is not required to deploy.

## Exhibition card

The separate PNG is 1920 × 1080 (16:9). Team number, names, final public URL, and QR remain clearly labeled pending real values. No placeholder or private draft address is encoded as a QR.

To regenerate with a verified publicly accessible address:

```sh
python3 tools/make_card.py --team 'TEAM NUMBER' --names 'Full Name, Full Name' --url 'https://OWNER.github.io/REPOSITORY/' --output PAC-LAB-exhibition-card.png
```

Replace the example address with your real, verified public address. The script uses Pillow, `qrcode`, and installed DejaVu fonts; it does not test hosting access. The TTF generator uses `fonttools` and produces the included original 5×7 pixel font.

## Remaining handoff fields

- Attach the standalone EndTerm Assignment before claiming compliance with its exact rubric or AI-use policy.
- Attach the Week 10 lecture before adding that district.
- Provide the old book source if preservation of its previous experiments must be audited.
- Complete team number, names, actual individual contributions, human review, and final public URL.

Do not substitute invented participant identities or fabricate student review signatures.
